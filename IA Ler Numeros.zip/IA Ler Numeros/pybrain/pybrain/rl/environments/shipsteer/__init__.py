from pybrain.rl.environments.shipsteer.shipsteer import ShipSteeringEnvironment
from pybrain.rl.environments.shipsteer.northwardtask import GoNorthwardTask