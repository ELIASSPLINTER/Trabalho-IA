from pybrain.structure.connections.full import FullConnection
from pybrain.structure.connections.identity import IdentityConnection
from pybrain.structure.connections.shared import SharedFullConnection, MotherConnection, SharedConnection
from pybrain.structure.connections.linear import LinearConnection
from pybrain.structure.connections.fullnotself import FullNotSelfConnection