from pybrain.auxiliary.gradientdescent import GradientDescent
from pybrain.auxiliary.gaussprocess import GaussianProcess
from pybrain.auxiliary.importancemixing import importanceMixing